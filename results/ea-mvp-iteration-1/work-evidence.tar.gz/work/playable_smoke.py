"""Local dummy-video smoke probe for the playable osu window."""

from pathlib import Path
import time
import wave

from project_b.osu.playable import PlayableMania


folder = Path(__file__).parent
audio = folder / "playable_smoke.wav"
beatmap = folder / "playable_smoke.osu"
with wave.open(str(audio), "wb") as output:
    output.setnchannels(2)
    output.setsampwidth(2)
    output.setframerate(44100)
    output.writeframes(b"\0\0\0\0" * 44100 * 5)
beatmap.write_text(
    "osu file format v14\n[General]\nAudioFilename: playable_smoke.wav\nMode: 3\n"
    "[Metadata]\nTitle: Smoke Test\nArtist: Spacefly\nVersion: 4K\n"
    "[Difficulty]\nCircleSize: 4\nOverallDifficulty: 8\n"
    "[TimingPoints]\n0,500,4,2,1,100,1,0\n1000,-50,4,2,1,100,0,0\n"
    "[HitObjects]\n64,192,1500,1,0,0:0:0:0:\n"
    "192,192,2000,128,0,3000:0:0:0:0:\n",
    encoding="utf-8",
)
client = PlayableMania([beatmap])
client._start()
assert client.scene == "play", client.message
assert client.beatmap.tap_count == 1
assert client.beatmap.hold_count == 1
client.anchor_ns = time.perf_counter_ns() - 1_000_000_000
client._draw_playfield(*client.screen.get_size())
client.pg.image.save(client.screen, str(folder / "playable_smoke.png"))
for ms, key, kind in ((1500, client.pg.K_d, client.pg.KEYDOWN),
                      (1510, client.pg.K_d, client.pg.KEYUP),
                      (2000, client.pg.K_f, client.pg.KEYDOWN),
                      (3000, client.pg.K_f, client.pg.KEYUP)):
    client.anchor_ns = time.perf_counter_ns() - ms * 1_000_000
    client._tick()
    client._handle_event(client.pg.event.Event(kind, key=key))
client.anchor_ns = time.perf_counter_ns() - 4_100_000_000
client._tick()
assert client.scene == "results", client.scene
assert client.game.score.snapshot().score == 1_000_000
client.pg.quit()
print("playable smoke PASS")
