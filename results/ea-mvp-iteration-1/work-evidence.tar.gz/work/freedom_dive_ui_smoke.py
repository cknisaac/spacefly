import time
from pathlib import Path

from project_b.osu.beatmap import extract_osz
from project_b.osu.playable import PlayableMania

archive = Path(r"C:\Users\imdef\AppData\Roaming\osu\exports\xi - FREEDOM DiVE (razlteh).osz")
normal = [path for path in extract_osz(archive) if "4K Normal" in path.name]
assert len(normal) == 1
app = PlayableMania(normal)
app._start()
assert app.scene == "play", app.message
assert app.beatmap and app.beatmap.audio_path.suffix.lower() == ".mp3"
app.anchor_ns = time.perf_counter_ns() - 1_900_000_000
app._tick()
assert app.music_started
app.screen.fill((0, 0, 0))
app._draw_playfield(*app.screen.get_size())
app.pg.image.save(app.screen, "work/freedom_dive_frame.png")
app._finish()
assert app.scene == "results"
app.screen.fill((0, 0, 0))
app._draw_results(*app.screen.get_size())
app.pg.image.save(app.screen, "work/freedom_dive_results.png")
app.pg.quit()
print("Freedom Dive MP3, playfield, and results smoke PASS")
