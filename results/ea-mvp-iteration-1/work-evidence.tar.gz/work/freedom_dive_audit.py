from collections import Counter
from pathlib import Path

from project_b.osu.beatmap import extract_osz, load_mania_beatmap
from project_b.osu.playable import ScrollMap
from project_b.osu.types import HoldNote
from project_b.osu.types import KeyAction, KeyActionKind
from project_b.osu.config import OsuConfig
from project_b.osu.mania_game import ManiaGame

archive = Path(r"C:\Users\imdef\AppData\Roaming\osu\exports\xi - FREEDOM DiVE (razlteh).osz")
maps = extract_osz(archive)
normal = [load_mania_beatmap(path) for path in maps if "4K Normal" in path.name]
assert len(normal) == 1
beatmap = normal[0]
print("sha256", beatmap.sha256)
print("chart", beatmap.title, beatmap.version)
print("tap", beatmap.tap_count, "hold", beatmap.hold_count,
      "audio", beatmap.audio_path.name, beatmap.audio_path.stat().st_size)
print("time", beatmap.notes[0].time_us, beatmap.end_time_us)
print("lane counts", dict(Counter(note.lane for note in beatmap.notes)))
print("timing points", len(beatmap.timing_points), "inherited",
      sum(not p.uninherited for p in beatmap.timing_points))
print("samples", beatmap.hitsound_count, "custom", len(beatmap.custom_samples))
for lane in range(4):
    lane_notes = sorted((note for note in beatmap.notes if note.lane == lane),
                        key=lambda note: note.time_us)
    overlaps = [(a.note_id, b.note_id)
                for a, b in zip(lane_notes, lane_notes[1:])
                if isinstance(a, HoldNote) and b.time_us < a.end_time_us]
    simultaneous = [(a.note_id, b.note_id)
                    for a, b in zip(lane_notes, lane_notes[1:])
                    if a.time_us == b.time_us]
    print("lane", lane, "hold overlaps", len(overlaps),
          "same-time objects", len(simultaneous))
scroll = ScrollMap(beatmap)
print("scroll samples", [(ms, round(scroll.position(ms * 1000)))
                         for ms in (0, 1000, 60000, 120000, 240000)])

game = ManiaGame(beatmap.notes, OsuConfig(od=beatmap.od, ruleset="lazer"))
events = []
for note in beatmap.notes:
    events.append((note.time_us, 1, note.lane, KeyActionKind.DOWN))
    end = note.end_time_us if isinstance(note, HoldNote) else note.time_us + 1000
    events.append((end, 0, note.lane, KeyActionKind.UP))
for at_us, _, lane, kind in sorted(events):
    game.apply_action(KeyAction(at_us, lane, kind))
score = game.finish()
print("perfect trace", len(game.actions), len(game.results), score.score,
      score.accuracy, score.max_combo, score.result_counts)
assert score.score == 1_000_000
assert score.max_combo == beatmap.tap_count + 2 * beatmap.hold_count
