"""Render the saved FD-4 fly trace through the existing Mania companion as MP4."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from project_b.ea_mvp.replay_companion import (  # noqa: E402
    DEFAULT_MAP,
    DEFAULT_TRACE,
    SavedFlyReplay,
    extract_osz,
    is_native_4k,
)
from project_b.osu.types import KeyAction, KeyActionKind  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "work/freedom_dive_fly_replay.mp4")
    parser.add_argument("--fps", type=int, default=30)
    args = parser.parse_args()
    if args.fps < 1 or args.fps > 120:
        parser.error("fps must be in 1..120")

    chart, = [p for p in extract_osz(DEFAULT_MAP)
              if is_native_4k(p) and "4K Normal" in p.name]
    replay = SavedFlyReplay(chart, DEFAULT_TRACE)
    assert replay.beatmap is not None and replay.game is not None
    expected = replay._trace["runs"][0]["score"]
    width, height = replay.screen.get_size()
    end_us = replay.beatmap.end_time_us + 4_000_000
    frames = (end_us * args.fps + 999_999) // 1_000_000
    args.output.parent.mkdir(parents=True, exist_ok=True)
    log_path = args.output.with_suffix(".ffmpeg.log")

    command = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "warning",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{width}x{height}",
        "-r", str(args.fps), "-i", "pipe:0",
        "-i", str(replay.beatmap.audio_path),
        "-map", "0:v:0", "-map", "1:a:0",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "24",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k",
        "-af", "apad", "-shortest", "-movflags", "+faststart",
        str(args.output),
    ]
    last_report = -1
    finished = False
    try:
        with log_path.open("wb") as log:
            encoder = subprocess.Popen(command, stdin=subprocess.PIPE,
                                       stdout=subprocess.DEVNULL, stderr=log)
            try:
                assert encoder.stdin is not None
                for frame in range(frames):
                    at_us = frame * 1_000_000 // args.fps
                    while (replay._action_index < len(replay._actions)
                           and replay._actions[replay._action_index]["time_us"] <= at_us):
                        row = replay._actions[replay._action_index]
                        replay.game.apply_action(KeyAction(
                            row["time_us"], row["lane"], KeyActionKind(row["kind"])))
                        replay._action_index += 1
                        key = "DFJK"[row["lane"]]
                        replay._last_action_label = (
                            f"{row['kind'].upper()} {key} at {row['time_us'] / 1_000_000:.3f}s")
                    replay.game.advance_to(max(at_us, replay.game.now_us))
                    replay.current_us = at_us
                    replay._time_us = lambda at_us=at_us: at_us
                    replay.last_result = replay.game.results[-1].result if replay.game.results else ""
                    if not finished and at_us >= replay.beatmap.end_time_us + 1_000_000:
                        replay.game.finish()
                        finished = True
                    replay.screen.fill((12, 16, 29))
                    if finished:
                        replay._draw_results(width, height)
                    else:
                        replay._draw_playfield(width, height)
                        # The companion and base renderer both draw help text here.
                        # The export has no keyboard controls, so replace that area.
                        replay.pg.draw.rect(replay.screen, (12, 16, 29),
                                            (0, height - 41, width, 41))
                        elapsed = at_us // 1_000_000
                        duration = replay.beatmap.end_time_us // 1_000_000
                        footer = (f"SAVED TRACE  •  {elapsed // 60}:{elapsed % 60:02d} "
                                  f"/ {duration // 60}:{duration % 60:02d}  •  "
                                  "Freedom Dive 4K Normal")
                        replay.screen.blit(replay.small.render(footer, True, (150, 165, 190)),
                                           (30, height - 30))
                    encoder.stdin.write(replay.pg.image.tostring(replay.screen, "RGB"))
                    report = at_us // 30_000_000
                    if report != last_report:
                        print(f"Rendered {at_us / 1_000_000:.0f}s / {end_us / 1_000_000:.0f}s", flush=True)
                        last_report = report
            finally:
                if encoder.stdin is not None:
                    encoder.stdin.close()
                code = encoder.wait()
        if code != 0:
            raise RuntimeError(f"ffmpeg exited {code}; see {log_path}")
        score = replay.game.score.snapshot()
        if (score.score != expected["score"]
                or abs(score.accuracy - expected["accuracy"]) > 1e-12
                or score.max_combo != expected["max_combo"]):
            raise RuntimeError(f"rendered outcome differs from trace: {score}")
        if replay._action_index != len(replay._actions):
            raise RuntimeError("render ended before all saved actions")
        print(f"Verified score {score.score}, accuracy {score.accuracy:.6%}, "
              f"max combo {score.max_combo}, actions {replay._action_index}", flush=True)
        print(f"Wrote {args.output} ({args.output.stat().st_size:,} bytes)", flush=True)
    finally:
        replay.pg.quit()


if __name__ == "__main__":
    main()
